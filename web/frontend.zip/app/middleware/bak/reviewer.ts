// ── Lumi — reviewer middleware ─────────────────────────────────────────────
// Redirects to /login if not authenticated, or to / if not reviewer/admin.
// Applied to the reviewer dashboard via definePageMeta({ middleware: ['auth', 'reviewer'] }).
// (Phase 6 will create the /review page that uses this.)

export default defineNuxtRouteMiddleware((to) => {
  const session = useUserSession()
  const user = session.value?.user as { id?: string; role?: string } | undefined

  if (!user?.id) {
    return navigateTo({
      path: '/login',
      query: { next: to.fullPath },
    })
  }

  if (user.role !== 'reviewer' && user.role !== 'admin') {
    return navigateTo('/')
  }
})
