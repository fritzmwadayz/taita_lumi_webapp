// ── Lumi — auth middleware ─────────────────────────────────────────────────
// Redirects to /login?next=<original_path> if the user is not authenticated.
// Applied to routes via definePageMeta({ middleware: 'auth' }).

export default defineNuxtRouteMiddleware((to) => {
  const session = useUserSession()
  const user = session.value?.user as { id?: string } | undefined

  if (!user?.id) {
    return navigateTo({
      path: '/login',
      query: { next: to.fullPath },
    })
  }
})
