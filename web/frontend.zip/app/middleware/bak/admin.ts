// ── Lumi — admin middleware ────────────────────────────────────────────────
// Redirects to /login if not authenticated, or to / if not admin.
// Applied to admin routes via definePageMeta({ middleware: ['auth', 'admin'] }).

export default defineNuxtRouteMiddleware((to) => {
  const session = useUserSession()
  const user = session.value?.user as { id?: string; role?: string } | undefined

  if (!user?.id) {
    return navigateTo({
      path: '/login',
      query: { next: to.fullPath },
    })
  }

  if (user.role !== 'admin') {
    return navigateTo('/')
  }
})
